package com.example.jobmanager;

import android.app.Activity;

public class FAQActivity extends Activity {
}
