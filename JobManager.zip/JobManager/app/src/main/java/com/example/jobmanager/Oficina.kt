package com.example.jobmanager

data class Oficina(val id: Int, val nombre: String, val ocupada: Boolean)